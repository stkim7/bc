1. 인증서 만료일자 확인

   ```
   kubeadm alpha certs check-expiration
   ```

2. 인증서 갱신

   ```
   kubeadm alpha certs renew all
   ```

   

