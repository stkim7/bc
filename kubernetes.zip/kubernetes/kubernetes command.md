### kubernetes command 정리

- kubernetes pod내 listening port 확인 방법
<pre>
    1. kubernetes pod list 조회
        kubectl -n <namespace> get pod -o wide
        ex) kubectl -n default get pod -o wide

    2. 1번에서 확인된 work node로 ssh 접속
    
    3. docker container id 조회  
        docker ps 
        
    4. 해당 docker의 pid 확인
        docker inspect <컨테이너 id> | grep -i pid
        ex) docker inspect 7aa9c2b03686 | grep -i pid
    
    5. listening port 확인
        nsenter -t <container pid> -n 명령어
        ex) sudo nsenter -t 94786 -n netstat -an 
</pre>

- nginx 컨테이너 실행
<pre>
    - kubectl run nginx --image nginx --port=80
        (실행되나 향후 deprecate 된다는 메시지 출력)

    <create 명령을 이용한 세팅>
    - kubectl create deployment nginx --image nginx
    
    <container port를 세팅할 경우>
    - kubectl create deployment nginx --image nginx --dry-run -o yaml > nginx.yaml
      (dry-run으로 yaml 파일을 생성한 후 port 정보 입력 후)
      <code>
        apiVersion: apps/v1
        kind: Deployment
        metadata:
          creationTimestamp: null
          labels:
            app: nginx
          name: nginx
        spec:
          replicas: 1
          selector:
            matchLabels:
              app: nginx
          strategy: {}
          template:
            metadata:
              creationTimestamp: null
              labels:
                app: nginx
            spec:
              containers:
              - image: nginx
                name: nginx
                ports:
                - containerPort: 80
                resources: {}
        status: {}
      </code>
    - kubectl apply -f nginx.yaml
      (파일을 통해 배포)
</pre>

- scale 방법
<pre>
kubectl scale deploy [deployment 이름] --replicas=[pod 수]
ex) kubectl scale deploy nginx --replicas=2
</pre>

- expose 방법
<pre>
kubectl expose deployment nginx --type=NodePort
</pre> 

- deployment 배포 history 확인
<pre>
kubectl rollout history deploy
kubectl rollout history deploy nginx
kubectl rollout history deploy nginx --revision=1
</pre>

- 롤백하기
<pre>
kubectl rollout undo deploy nginx
kubectl rollout undo deploy nginx --to-revision=3
</pre>
- 서비스 dns full FQDN 확인
<pre>
kubectl run curl --image=radial/busyboxplus:curl -it
nslookup <service 이름>
kubectl run -n default curl --image=radial/busyboxplus:curl -it 
kubectl attach curl-69c656fd45-47z9k -c curl -it 
kubectl run mgmt-tool --image=stkim7/mgmt-tool:1.0 --image-pull-policy=Always -it -- bash
</pre>



- dnsutil 설치
<pre>
kubectl apply -f https://k8s.io/examples/admin/dns/dnsutils.yaml
kubectl exec -ti dnsutils -- nslookup kubernetes.default
</pre>

- istio injection
<pre>
istioctl kube-inject -f samples/sleep/sleep.yaml | kubectl apply -f -
</pre>