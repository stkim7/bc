- selinux 설정

  ```
  setenforce 0 
  sed -i 's/^SELINUX=enforcing$/SELINUX=disabled/' /etc/selinux/config
  ```

- /etc/security/limits.conf 설정

  ```
  * soft nproc 131072
  * hard nproc 131072
  * soft nofile 307200
  * hard nofile 307200
  * soft memlock unlimited
  * hard memlock unlimited
  ```
  
- mod_probe 모듈 로드

  ```
  sudo modprobe br_netfilter
  
  cat <<EOF | sudo tee /etc/modules-load.d/k8s.conf
  br_netfilter
  EOF
  
  cat <<EOF | sudo tee /etc/sysctl.d/k8s.conf
  net.bridge.bridge-nf-call-ip6tables = 1
  net.bridge.bridge-nf-call-iptables = 1
  net.ipv4.ip_forward=1
  EOF
  sudo sysctl --system
  ```
  
- /etc/sysctl.conf 설정

  ```
  vm.swappiness = 0
  net.ipv4.conf.all.accept_redirects=0
  net.ipv6.conf.all.accept_redirects=0
  net.ipv4.conf.all.secure_redirects=0
  net.ipv4.conf.all.send_redirects=0
  kernel.nmi_watchdog=1
  kernel.shmall=4294967296
  kernel.shmmax=68719476736
  kernel.shmmni=4096
  kernel.sem=1000 32000 100 512
  kernel.msgmax=65536
  kernel.msgmnb=65536
  kernel.msgmni=2878
  kernel.sysrq=0
  kernel.core_uses_pid=1
  vm.vfs_cache_pressure=10000
  vm.max_map_count=262144
  net.core.rmem_default=33554432
  net.core.rmem_max=33554432
  net.core.wmem_default=33554432
  net.core.wmem_max=33554432
  net.core.optmem_max=33554432
  net.core.somaxconn=65535
  net.core.netdev_max_backlog=3000
  net.ipv4.tcp_mem=10000000 10000000 10000000
  net.ipv4.tcp_rmem=10000000 10000000 10000000
  net.ipv4.tcp_wmem=10000000 10000000 10000000
  net.ipv4.tcp_keepalive_time=20
  net.ipv4.tcp_keepalive_intvl=15
  net.ipv4.tcp_keepalive_probes=5
  net.ipv4.tcp_fin_timeout=30
  net.ipv4.ip_local_port_range=10000 65500
  net.ipv4.tcp_retries1=3
  net.ipv4.tcp_retries2=3
  net.ipv4.tcp_rfc1337=0
  net.ipv4.tcp_max_syn_backlog=8192
  net.ipv4.tcp_moderate_rcvbuf=1
  net.ipv4.tcp_congestion_control=cubic
  net.ipv4.tcp_sack=1
  net.ipv4.tcp_syn_retries=2
  net.ipv4.tcp_syncookies=1
  net.ipv4.tcp_timestamps=1
  net.ipv4.tcp_window_scaling=1
  net.ipv4.tcp_orphan_retries=0
  net.ipv4.conf.default.rp_filter=1
  net.ipv4.conf.default.accept_source_route=0
  fs.file-max=8000000
  fs.aio-max-nr=65536
  vm.overcommit_memory=1
  ```
  
- vm 이미지 ip 변경

  ```
  sudo vi /etc/sysconfig/network-scripts/ifcfg-ens33 수정
  ```
  
- 계정 만들기

  ```
  groupadd stkim7
  useradd -d /home/stkim7 -s /bin/bash -g stkim7 stkim7
  passwd stkim7
  ```

- sudoers 등록

  ```
  - vi /etc/sudoers
    ( stkim7  ALL=(ALL)       NOPASSWD: ALL )
  ```

- hostname 설정 및 host 등록

  ```
  hostnamectl set-hostname k8s-master
  hostnamectl set-hostname k8s-node01
  hostnamectl set-hostname k8s-node02
  
  vi /etc/hosts
  192.168.32.21   k8s-master
  192.168.32.22   k8s-node01
  192.168.32.23   k8s-node02
  ```

- 필요한 package 설치

  ```
  sudo yum install deltarpm net-tools telnet wget
  ```

- 도커설치

  ```
  - 오래된 도커 지우기
    sudo yum remove docker \
                    docker-client \
                    docker-client-latest \
                    docker-common \
                    docker-latest \
                    docker-latest-logrotate \
                    docker-logrotate \
                    docker-engine
                    
  - 도커 Repository 설정
    sudo yum install -y yum-utils
    
    sudo yum-config-manager \
      --add-repo \
      https://download.docker.com/linux/centos/docker-ce.repo
  
  - 도커설치
    sudo yum install docker-ce docker-ce-cli containerd.io
  ```

- daemon 설정

  ```
  sudo mkdir -p /etc/docker
  
  sudo bash -c "cat > /etc/docker/daemon.json" <<EOF
  {
    "exec-opts": ["native.cgroupdriver=systemd"],
    "log-driver": "json-file",
    "log-opts": {
      "max-size": "100m"
    },
    "storage-driver": "overlay2",
    "storage-opts": [
      "overlay2.override_kernel_check=true"
    ]
  }
  EOF
  ```

- 도커 그룹에 사용자 추가

  ```
  sudo usermod -aG docker stkim7 (재 접속 필요)
  ```

- 도커시작

  ```
  sudo systemctl enable docker
  sudo systemctl daemon-reload
  sudo systemctl start docker
  ```

- 테스트

  ```
  docker run -p 8081:80 nginx
  ```

- kubernetes 설치 준비

  ```
  - br_netfilter 모듈 로드
    sudo modprobe br_netfilter
    
  - iptables 관련 설정
    cat <<EOF >  /etc/sysctl.d/k8s.conf
  net.bridge.bridge-nf-call-ip6tables = 1
  net.bridge.bridge-nf-call-iptables = 1
  EOF
  - sysctl --system
    
  -swap 끄기
  vi /etc/sysctl.conf
  	vm.swappiness = 0 
  
  - echo 0 > /proc/sys/vm/swappiness
  - swapoff -a
  ```
  
- kubernetes repository 등록

  ```
  cat <<EOF | sudo tee /etc/yum.repos.d/kubernetes.repo
  [kubernetes]
  name=Kubernetes
  baseurl=https://packages.cloud.google.com/yum/repos/kubernetes-el7-\$basearch
  enabled=1
  gpgcheck=1
  repo_gpgcheck=1
  gpgkey=https://packages.cloud.google.com/yum/doc/yum-key.gpg https://packages.cloud.google.com/yum/doc/rpm-package-key.gpg
  exclude=kubelet kubeadm kubectl
  EOF
  ```
  
- kubernetes 설치

  ```
  sudo yum install -y kubelet kubeadm kubectl --disableexcludes=kubernetes
  sudo systemctl enable --now kubelet;
  sudo systemctl daemon-reload;
  sudo systemctl restart kubelet
  ```
  
- 마스터 노드 초기화 전 이미지 먼저 다운로드

  ```
  kubeadm config images pull
  ```

- 마스터 노드 초기화

  ```
  sudo kubeadm init --pod-network-cidr=10.244.0.0/16 --apiserver-advertise-address=192.168.32.21
  
  <마스터 노드 초기화 이후 출력된 join 관련 메시지 - token & ca cert 매번 바뀜>
  sudo kubeadm join 192.168.32.21:6443 --token hcw6k1.dmyw6eqa2zfqmxh4 \
          --discovery-token-ca-cert-hash sha256:615fe96927e227f173dd3df8d7659df761910c6cacb0fc6f79a4e806c46b326a
  ```

- config 복사

  ```
  mkdir -p $HOME/.kube;
  sudo cp -i /etc/kubernetes/admin.conf $HOME/.kube/config;
  sudo chown $(id -u):$(id -g) $HOME/.kube/config
  
  - 각 노드에서도 접속 하려면 copy 필요
  ```

- kubernetes pod network 설치 (이 부분 새로운 버전 체크해야 설치해야 함)

  ```
  참고문서: https://github.com/coreos/flannel/blob/master/Documentation/kubernetes.md
  https://github.com/coreos/flannel/tree/master/Documentation
  
  kubectl apply -f https://raw.githubusercontent.com/coreos/flannel/master/Documentation/kube-flannel.yml
  ```

- 쿠버네티스 라벨 추가

  ```
  kubectl label nodes k8s-node01 node-role.kubernetes.io/node01=
  kubectl label nodes k8s-node02 node-role.kubernetes.io/node02=
  ```

- kubernetes 노드 확인

  ```
  kubectl get nodes
  ```

  

