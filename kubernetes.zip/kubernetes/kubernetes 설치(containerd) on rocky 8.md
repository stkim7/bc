1. 계정생성

   ```
   groupadd stkim7;
   useradd -d /home/stkim7 -s /bin/bash -g stkim7 stkim7;
   passwd stkim7
   ```

2. sudoers 등록

   ```
   chmod +w /etc/sudoers
   sudo vi /etc/sudoers
   ```

3. selinux 설정

   ```
   setenforce 0 
   sed -i 's/^SELINUX=enforcing$/SELINUX=disabled/' /etc/selinux/config
   ```

4. 방화벽 disable

   ```
   sudo systemctl disable firewalld;
   sudo systemctl stop firewalld
   ```

5. hostname 설정 및 등록

   ```
   sudo hostnamectl set-hostname k8s01
   sudo hostnamectl set-hostname k8s02
   sudo vi /etc/hosts
     192.168.33.71   k8s01
     192.168.33.72   k8s02
   ```

6. /etc/security/limits.conf 설정

   ```
   * soft nproc 131072
   * hard nproc 131072
   * soft nofile 307200
   * hard nofile 307200
   * soft memlock unlimited
   * hard memlock unlimited
   ```

7. sysctl.conf 설정

   ```
   sudo modprobe br_netfilter;
   sudo modprobe overlay
   
   cat <<EOF | sudo tee /etc/modules-load.d/k8s.conf
   br_netfilter
   overlay
   EOF
   
   cat <<EOF | sudo tee /etc/sysctl.d/k8s.conf
   net.bridge.bridge-nf-call-ip6tables = 1
   net.bridge.bridge-nf-call-iptables = 1
   net.ipv4.ip_forward=1
   EOF
   
   sudo sysctl --system
   
   sudo vi /etc/sysctl.conf
   vm.swappiness = 0
   net.ipv4.conf.all.accept_redirects=0
   net.ipv6.conf.all.accept_redirects=0
   net.ipv4.conf.all.secure_redirects=0
   net.ipv4.conf.all.send_redirects=0
   kernel.shmall=4294967296
   kernel.shmmax=68719476736
   kernel.shmmni=4096
   kernel.sem=1000 32000 100 512
   kernel.msgmax=65536
   kernel.msgmnb=65536
   kernel.msgmni=2878
   kernel.sysrq=0
   kernel.core_uses_pid=1
   vm.vfs_cache_pressure=10000
   vm.max_map_count=262144
   net.core.rmem_default=33554432
   net.core.rmem_max=33554432
   net.core.wmem_default=33554432
   net.core.wmem_max=33554432
   net.core.optmem_max=33554432
   net.core.somaxconn=65535
   net.core.netdev_max_backlog=3000
   net.ipv4.tcp_mem=10000000 10000000 10000000
   net.ipv4.tcp_rmem=10000000 10000000 10000000
   net.ipv4.tcp_wmem=10000000 10000000 10000000
   net.ipv4.tcp_keepalive_time=20
   net.ipv4.tcp_keepalive_intvl=15
   net.ipv4.tcp_keepalive_probes=5
   net.ipv4.tcp_fin_timeout=30
   net.ipv4.ip_local_port_range=10000 65500
   net.ipv4.tcp_retries1=3
   net.ipv4.tcp_retries2=3
   net.ipv4.tcp_rfc1337=0
   net.ipv4.tcp_max_syn_backlog=8192
   net.ipv4.tcp_moderate_rcvbuf=1
   net.ipv4.tcp_congestion_control=cubic
   net.ipv4.tcp_sack=1
   net.ipv4.tcp_syn_retries=2
   net.ipv4.tcp_syncookies=1
   net.ipv4.tcp_timestamps=1
   net.ipv4.tcp_window_scaling=1
   net.ipv4.tcp_orphan_retries=0
   net.ipv4.conf.default.rp_filter=1
   net.ipv4.conf.default.accept_source_route=0
   fs.file-max=8000000
   fs.aio-max-nr=65536
   vm.overcommit_memory=1
   ```

8. disable swap 

   ```
   sudo swapoff -a
   
   sudo vi /etc/fstab swap 주석 처리
   ```

9. containerd 설치

   ```
   sudo yum update -y
   
   sudo yum install yum-utils iproute-tc -y 
   
   sudo yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
   
   sudo yum install containerd.io -y
   
   sudo systemctl enable --now containerd
   
   sudo bash -c "containerd config default > /etc/containerd/config.toml"
   
   sudo sed -i 's/ SystemdCgroup = false/ SystemdCgroup = true/' /etc/containerd/config.toml
   
   sudo systemctl restart containerd
   ```

10. kubernetes 설치

   ```
   cat <<EOF | sudo tee /etc/yum.repos.d/kubernetes.repo
   [kubernetes]
   name=Kubernetes
   baseurl=https://pkgs.k8s.io/core:/stable:/v1.36/rpm/
   enabled=1
   gpgcheck=1
   gpgkey=https://pkgs.k8s.io/core:/stable:/v1.36/rpm/repodata/repomd.xml.key
   exclude=kubelet kubeadm kubectl cri-tools kubernetes-cni
   EOF
   
   sudo yum install -y kubelet kubeadm kubectl --disableexcludes=kubernetes
   
   sudo systemctl enable --now kubelet
   ```

11. 마스터 노드 초기화 전 이미지 pull

    ```
    sudo kubeadm config images pull               
    ```

12. 마스터 노드 초기화

    ```
    sudo kubeadm init --pod-network-cidr=10.244.0.0/16 --apiserver-advertise-address=192.168.33.12
    
    -- kubeadm init 새로 적용 시 kubeadm reset 후 진행 
    
    <마스터 노드 초기화 이후 출력된 join 관련 메시지 - token & ca cert 매번 바뀜>
    sudo kubeadm join 192.168.32.94:6443 --token hcw6k1.dmyw6eqa2zfqmxh4 \
            --discovery-token-ca-cert-hash sha256:615fe96927e227f173dd3df8d7659df761910c6cacb0fc6f79a4e806c46b326a
    ```
    
13. config 복사

    ```
    mkdir -p $HOME/.kube;
    sudo cp -i /etc/kubernetes/admin.conf $HOME/.kube/config;
    sudo chown $(id -u):$(id -g) $HOME/.kube/config
    
    - 각 노드에서도 접속 하려면 copy 필요
    ```

14. kubernetes pod network 설치 (이 부분 새로운 버전 체크해야 설치해야 함)

    ```
    curl https://raw.githubusercontent.com/projectcalico/calico/v3.32.1/manifests/calico.yaml -O
    
    # - name: CALICO_IPV4POOL_CIDR
    #   value: "172.16.0.0/24"
                
    # kubectl apply -f calico.yaml
    or
    
    참고문서: https://github.com/coreos/flannel/blob/master/Documentation/kubernetes.md
    https://github.com/coreos/flannel/tree/master/Documentation
    
    kubectl apply -f https://raw.githubusercontent.com/coreos/flannel/master/Documentation/kube-flannel.yml
    
    or
    
    참고문서: https://github.com/coreos/flannel/blob/master/Documentation/kubernetes.md
    https://github.com/coreos/flannel/tree/master/Documentation
    
    kubectl apply -f https://raw.githubusercontent.com/coreos/flannel/master/Documentation/kube-flannel.yml
    ```

15. 쿠버네티스 라벨 추가

    ```
    kubectl label nodes worker01 node-role.kubernetes.io/worker=
    kubectl label nodes k8s-worker02 node-role.kubernetes.io/worker=
    ```

16. kubernetes 노드 확인

    ```
    kubectl get nodes
    ```

    