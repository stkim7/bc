1. internet 되는 pc 에서 docker를 실행하여 apk를 다운로드 한다

   ```
   docker run -it openjdk:8u212-alpine3.9 -v /home/stkim7/work:/work sh
   ```

2.  timezone apk를 설치한다

   ```
   apk add tzdata
   ```

3. 설치된 apk를 저장 한다

   ```
   apk fetch tzdata
   ```

4. tzdata를 copy하여 image에 설치한다

   ```
   docker run -it openjdk:8u212-alpine3.9 -v /home/stkim7/work:/work sh
   touch repo.list
   apk add --repositories-file=repo.list --allow-untrusted --no-network --no-cache ./tzdata-2020c-r1.apk
   ```

5. docker image를 commit 하고 commit 한다

   ```
   docker ps -a
   docker commit [container 이미지]
   docker tag wise.net/nginx:1.0
   docker push
   ```

6. docker file을 아래와 같이 작성한다

   ```
   RUN cp /usr/share/zoneinfo/Asia/Seoul /etc/localtime && echo "Asia/Seoul" > /etc/timezone
   ```

   