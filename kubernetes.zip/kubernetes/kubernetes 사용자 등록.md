1. 신규 namespace 생성

   ```
   kubectl create namespace stkim7
   ```

2. 신규 User account 생성을 위한 인증서 생성

   ```
   - client private kye 생성
     openssl genrsa -out stkim7.key 2048
     
   - crt 생성을 위한 csr 생성
     (CN| kubernetes Service Account하고 일치해야 함)
     openssl req -new -key stkim7.key -subj "/CN=stkim7/O=Kubernetes Korea Group" -out stkim7.csr
   
   - client csr 파일 생성
     openssl x509 -req -in stkim7.csr -CA /etc/kubernetes/pki/ca.crt -CAkey /etc/kubernetes/pki/ca.key -CAcreateserial -out stkim7.crt -days 7300
   ```
   
3. 새로운 namespace로 접근 role 설정

   ```
   # vi role.yaml
   
   apiVersion: rbac.authorization.k8s.io/v1
   kind: Role
   metadata:
     namespace: stkim7
     name: stkim7-manager
   rules:
   - apiGroups: ["", "extensions", "apps"]
     resources: ["deployments", "replicasets", "pods", "services", "nodes"]
     verbs: ["get", "list", "watch", "create", "update", "patch", "delete"]
   
   # kubectl apply -f role.yaml
   ```

4. User와 Role 연결 (rolebinding 생성)

   ```
   # vi rolebinding.yaml
   
   apiVersion: rbac.authorization.k8s.io/v1
   
   kind: RoleBinding
   metadata:
     name: stkim7-manager-rolebinding
     namespace: stkim7
   subjects:
   
   - kind: User
     name: stkim7
     apiGroup: rbac.authorization.k8s.io
   roleRef:
     kind: Role
     name: stkim7-manager
     apiGroup: rbac.authorization.k8s.io
   
   # kubectl apply -f rolebinding.yaml
   ```

5. kubectl config context 생성

   ```
   kubectl config set-credentials stkim7 --client-certificate=/root/temp/stkim7.crt --client-key=/root/temp/stkim7.key --embed-certs=true
   
   kubectl config get-clusters NAME cluster.local 해서 cluster 이름 확인
   
   # kubectl config set-context stkim7@kubernetes --cluster=kubernetes --user=stkim7 --namespace=stkim7
   ```

6. kubernetes 접속

   ```
   # context 확인
   kubectl config get-contexts
   
   # context 변경
   kubectl config use-context stkim7@kubernetes
   ```

7. admin.conf에서 인증서 추출

   ```
   sudo cat $KUBECONFIG_PATH | grep client-certificate-data | cut -f2 -d : | tr -d ' ' | base64 -d | openssl x509 -text -in -
   ```

   