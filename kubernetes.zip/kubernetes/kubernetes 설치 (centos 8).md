1. kubectl binary 설치

   ```
   curl -LO "https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/linux/amd64/kubectl"
   ```

2. 바이너리 검증(선택 사항)

   ```
   curl -LO "https://dl.k8s.io/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/linux/amd64/kubectl.sha256"
   echo "$(cat kubectl.sha256)  kubectl" | sha256sum --check
   ```

3. kubectl 설치

   ```
   sudo install -o root -g root -m 0755 kubectl /usr/local/bin/kubectl
   ```

4. 

