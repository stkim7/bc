### kubernetes dashboard 설치
- dashboard 구성 yaml을 다운로드 한다.  

  ```
  wget https://raw.githubusercontent.com/kubernetes/dashboard/v2.7.0/aio/deploy/recommended.yaml
  ```


- namespace를 생성한다

  ```
  apiVersion: v1
  kind: Namespace
  metadata:
    name: kubernetes-dashboard
  ```

- 인증서를 생성하여 배포한다

  ```
  kubectl create secret generic kubernetes-dashboard-certs --from-file=certs -n kubernetes-dashboard
  ```

- 다운로드된 파일의 내용을 열어 자동으로 tls 인증서와 key가 생성되지 않도록 수정한다.

  (위에서 배포한 secret이 mount 됨)

  ```
  args:
      - --tls-cert-file=/dashboard.crt # 추가
      - --tls-key-file=/dashboard.key # 추가
      # - --enable-skip-login
      - --token-ttl=0 # dashboard sessesion timeout disable # 추가
      # - --auto-generate-certificates (이 부분 수정)
  ```

- dashboard를 배포

  ```
  kubectl apply -f recommended.yaml
  ```

- 서비스 계정을 만듦

  ```
  apiVersion: v1
  kind: ServiceAccount
  metadata:
    name: admin-user
    namespace: kubernetes-dashboard
  ---
  apiVersion: rbac.authorization.k8s.io/v1
  kind: ClusterRoleBinding
  metadata:
    name: admin-user-crb
  roleRef:
    apiGroup: rbac.authorization.k8s.io
    kind: ClusterRole
    name: cluster-admin
  subjects:
  - kind: ServiceAccount
    name: admin-user
    namespace: kubernetes-dashboard
  ---
  apiVersion: v1
  kind: Secret
  type: kubernetes.io/service-account-token
  metadata:
    name: admin-user-token
    namespace: kubernetes-dashboard
    annotations:
      kubernetes.io/service-account.name: admin-user
  ---
  # 설치 시 생성된 kubernetes-dashboard에 권한 부여할 때
  kind: ClusterRoleBinding
  metadata:
    name: kubernetes-dashboard
  roleRef:
    apiGroup: rbac.authorization.k8s.io
    kind: ClusterRole
    name: cluster-admin
  subjects:
    - kind: ServiceAccount
      name: kubernetes-dashboard
      namespace: kubernetes-dashboard
  
  
  ```

- node port 설정

  k edit service -n kubernetes-dashboard

```
eyJhbGciOiJSUzI1NiIsImtpZCI6InAwUk5YamFJRm04U2pfSWZ4S0Rjb2U2OFc4aU45Wjd2MWg1Nm9OOWt3aDgifQ.eyJpc3MiOiJrdWJlcm5ldGVzL3NlcnZpY2VhY2NvdW50Iiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9uYW1lc3BhY2UiOiJrdWJlcm5ldGVzLWRhc2hib2FyZCIsImt1YmVybmV0ZXMuaW8vc2VydmljZWFjY291bnQvc2VjcmV0Lm5hbWUiOiJrdWJlcm5ldGVzLWRhc2hib2FyZC10b2tlbiIsImt1YmVybmV0ZXMuaW8vc2VydmljZWFjY291bnQvc2VydmljZS1hY2NvdW50Lm5hbWUiOiJrdWJlcm5ldGVzLWRhc2hib2FyZCIsImt1YmVybmV0ZXMuaW8vc2VydmljZWFjY291bnQvc2VydmljZS1hY2NvdW50LnVpZCI6IjllYzU2NWJhLTdiNTMtNGVjYi05ZWFhLWQwNTIyNGE1ODExMSIsInN1YiI6InN5c3RlbTpzZXJ2aWNlYWNjb3VudDprdWJlcm5ldGVzLWRhc2hib2FyZDprdWJlcm5ldGVzLWRhc2hib2FyZCJ9.EI0QAJd9-oFUkgH8Aix_zW6W17OHxRva5ac9Pll34l1Bc7KOFruaOZAC4M2BTzJRYx1e8ptXtMXgY8t8DkLvnL2uaolR0WIJDuJ5qL3fEknXnNr1ryt8f_kwe7ODLWkvnIG2OerkDwzbg7hK1BDkyMTVoxIc8BqwTAoaNhkCGjRn4b9beToSI_kqlnWVdVTtuGekZOKwBFUDXei7NrwpQ16C0js-7YPKHev8SzBzOBbAXSG-ET4G1Phv28nMnNSzwLtx_k7y4wsaoZ6ITgTzjAmGzQYuEOxaZp1OOfRUbOeamXTqQ3qWOrqfn9yWjOO5nfyr872P-podNJAsserWKg
```

