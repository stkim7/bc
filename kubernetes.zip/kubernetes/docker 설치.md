1. yum-util 설치

   ```
   sudo yum install -y yum-utils
   ```

2. yum repository 추가

   ```
   sudo yum-config-manager \
       --add-repo \
       https://download.docker.com/linux/centos/docker-ce.repo
   ```

3. docker engine 설치

   ```
   sudo yum install docker-ce docker-ce-cli containerd.io
   ```

4. docker 시작

   ```
   sudo systemctl start docker
   ```

5. 권한 부여

   ```
   sudo usermod -aG docker <your-user>
   ```

6. docker options 설정

   ```
   DOCKER_OPTS="--dns 8.8.8.8 --dns 8.8.4.4 -g /home/bitcore/docker-data"
   ```

   