### docker remote access 가능 설정

<pre>
sudo vi /lib/systemd/system/docker.service
-- 수정 내용
#ExecStart=/usr/bin/dockerd -H fd:// --containerd=/run/containerd/containerd.sock
ExecStart=/usr/bin/dockerd -H unix:///var/run/docker.sock -H tcp://0.0.0.0

-- docker service restart
sudo systemctl daemon-reload
sudo systemctl restart docker

-- client 사용 방법
export DOCKER_HOST="tcp://0.0.0.0:2375"
or
docker -H tcp://0.0.0.0:2375 ps
</pre>
