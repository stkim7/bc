#### 도커명령어 정리

- docker 일반 계정에서 사용 권한 부여  
    usermod -aG docker $USER
    
- docker 버전 확인  
    docker version

-  도커 실행환경 확인  
    docker system info

- 도커가 실행하고 있는 디스크 상황 학인  
    docker system df  

- 도커 이미지 목록 확인
    docker image ls  
    docker image ls -a        --->모든(중간 이미지까지) 이미지를 표시  
    docker image ls --digests   ---> 다이제스트를 표시  
    docker image ls -q        ---> docker image id만 표시  

- 도커 이미지 다운로드  
    docker pull [다운받을아이템]  
    docker image pull [다운받을아이템]  
    docker image pull [다운받을아이템]:[태그명]               ---> 지정한 태그의 아이템을 다운로드
    docker image pull -a [다운받을아이템]                     ---> 해당 아이템의 모든 태그를 다운로드
    docker image pull  gcr.io.tensorflow/[다운받을아이템]     ---> url로 부터 다운로드

- docker container 실행  
    docker container --name [컨테이너명] -d -p 80:80 [이미지명]  
    ex) docker container --name webserver -d -p 80:80 nginx
    
- 도커 컨테이너 목록 확인  
    docker container ps

- 도커 컨테이너 상세 확인  
    docker container stats [컨테이너명]
    
- 도커 이미지 상세 확인
    docker container stats [컨테이너명]

- 도커 이미지 태그
    docker image tag [아이템명] [docker hub 사용자명]/이미지명:태그명  

- 도커 허브에서 검색
    docker search [아이템명]
    
- docker 이미지 삭제  
    docker image rm nginx  
    docker image rm -f nginx       ---> image 강제 삭제
    
- 사용하지 않는 이미지 삭제  
    docker image prune  
    docker image prune -a (사용하지 않는 이미지 모두 삭제)  
    docker image prune -f (사용하지 않는 이미지를 강제 삭제) 

- 도커 이미지 업로드
    docker image push [docker hub 사용자명]/[이미지명]:[태그명]
    docker image push reo/nginx:1.1
    docker image push reo/nginx
    
- 컨테이너 모두 삭제
    
    docker rm $(docker ps -a -q)
    
      
    
    
    ​    