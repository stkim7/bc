#### golang docker image 만드는 방법

- golang alpine 도커 이미지 다운로드   
    docker pull golang:1.14.2-alpine3.11
    
- 빌드할 소스를 다운로드   
    git clone or git checkout
    
- 참조 패키지를 vendor에 모음   
    go mod vendor
    
- multi stage docker file 작성
<pre>
     # stage 1: copy source & build
     
     FROM golang:1.14.2-alpine3.11 AS build
     MAINTAINER Seongtae Kim <stkim7@gmail.com>
     
     WORKDIR /go/src
     COPY ./go/src/example example
     RUN go install ./example/gorilla-mux
     
     # stage 2: copy stage1's binary only
     FROM golang:1.14.2-alpine3.11
     MAINTAINER Seongtae Kim <stkim7@gmail.com>
     
     # copy stage1's binary from build
     COPY --from=build /go/bin/gorilla-mux /go/bin/
     
     CMD ["gorilla-mux"]
</pre>          

- 도커 빌드  
    docker build --tag test:0.1 .
    
- 첫번째 stage에서 생성된 tag가 없는 이미지 삭제  
    docker image prune -f

- final 생성된 이미지 확인   
    docker images | grep test | grep 0.1            